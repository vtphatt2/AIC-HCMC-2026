#include <torch/extension.h>

#include <cstdint>

namespace py = pybind11;

// Expanded-K modes:
// 0: 1-term  = XhWh
// 1: 2-termA = XhWh + XlWh
// 2: 2-termW = XhWh + XhWl
// 3: 3-term  = XhWh + XhWl + XlWh
// 4: 4-term  = XhWh + XhWl + XlWh + XlWl

torch::Tensor pack_weight_cuda(torch::Tensor W, int64_t mode);
torch::Tensor pack_activation_out_cuda(torch::Tensor X, torch::Tensor X_pack, int64_t mode);
torch::Tensor gemm_prepacked_out_cuda(torch::Tensor X_pack, torch::Tensor W_pack, torch::Tensor Out);
torch::Tensor emulated_matmul_packed_out_cuda(
    torch::Tensor X,
    torch::Tensor W_pack,
    torch::Tensor X_pack,
    torch::Tensor Out,
    int64_t mode);

// Scaled two-GEMM method:
// A = Xh Wh
// G = (Xh + s Xl)(Wh + s Wl)
// Y = ((s - 1) / s) A + (1 / s) G
//   = A + XhWl + XlWh + s XlWl, before packing-rounding effects.
torch::Tensor pack_scaled_weight_cuda(torch::Tensor W, int64_t scale);
torch::Tensor pack_scaled_activation_out_cuda(
    torch::Tensor X, torch::Tensor X_pair, int64_t scale);
torch::Tensor scaled_two_gemm_out_cuda(
    torch::Tensor X,
    torch::Tensor W_pair,
    torch::Tensor X_pair,
    torch::Tensor Out,
    int64_t scale);

static int64_t segments_for_mode(int64_t mode) {
    TORCH_CHECK(mode >= 0 && mode <= 4, "mode must be in [0, 4]");
    if (mode == 0) return 1;
    if (mode == 1 || mode == 2) return 2;
    if (mode == 3) return 3;
    return 4;
}

static void check_scale(int64_t scale) {
    TORCH_CHECK(scale >= 2 && scale <= 1024,
                "scale must be a power of two in [2, 1024]");
    TORCH_CHECK((scale & (scale - 1)) == 0,
                "scale must be a power of two");
}

static void check_cuda_contiguous(const torch::Tensor& t, const char* name) {
    TORCH_CHECK(t.is_cuda(), name, " must be CUDA");
    TORCH_CHECK(t.is_contiguous(), name, " must be contiguous");
}

torch::Tensor pack_weight(torch::Tensor W, int64_t mode) {
    check_cuda_contiguous(W, "W");
    TORCH_CHECK(W.dtype() == torch::kFloat32, "W must be FP32");
    TORCH_CHECK(W.dim() == 2, "W must have shape [K, N]");
    TORCH_CHECK(W.size(0) > 0 && W.size(1) > 0, "W dimensions must be positive");
    TORCH_CHECK(W.size(0) % 8 == 0 && W.size(1) % 8 == 0,
                "K and N should be multiples of 8 for the fast Tensor Core path");
    segments_for_mode(mode);
    return pack_weight_cuda(W, mode);
}

torch::Tensor pack_activation_out(torch::Tensor X, torch::Tensor X_pack, int64_t mode) {
    check_cuda_contiguous(X, "X");
    check_cuda_contiguous(X_pack, "X_pack");
    TORCH_CHECK(X.dtype() == torch::kFloat32, "X must be FP32");
    TORCH_CHECK(X_pack.dtype() == torch::kFloat16, "X_pack must be FP16");
    TORCH_CHECK(X.dim() == 2 && X_pack.dim() == 2, "X and X_pack must be matrices");
    TORCH_CHECK(X.device() == X_pack.device(), "X and X_pack must be on the same device");
    const int64_t segments = segments_for_mode(mode);
    TORCH_CHECK(X_pack.size(0) == X.size(0), "X_pack M mismatch");
    TORCH_CHECK(X_pack.size(1) == segments * X.size(1),
                "X_pack must have shape [M, segments*K]");
    return pack_activation_out_cuda(X, X_pack, mode);
}

torch::Tensor gemm_prepacked_out(torch::Tensor X_pack, torch::Tensor W_pack, torch::Tensor Out) {
    check_cuda_contiguous(X_pack, "X_pack");
    check_cuda_contiguous(W_pack, "W_pack");
    check_cuda_contiguous(Out, "Out");
    TORCH_CHECK(X_pack.dtype() == torch::kFloat16, "X_pack must be FP16");
    TORCH_CHECK(W_pack.dtype() == torch::kFloat16, "W_pack must be FP16");
    TORCH_CHECK(Out.dtype() == torch::kFloat32, "Out must be FP32");
    TORCH_CHECK(X_pack.dim() == 2 && W_pack.dim() == 2 && Out.dim() == 2,
                "X_pack, W_pack and Out must be matrices");
    TORCH_CHECK(X_pack.device() == W_pack.device() && X_pack.device() == Out.device(),
                "all tensors must be on the same device");
    TORCH_CHECK(X_pack.size(1) == W_pack.size(0), "effective K mismatch");
    TORCH_CHECK(Out.size(0) == X_pack.size(0) && Out.size(1) == W_pack.size(1),
                "Out must have shape [M, N]");
    return gemm_prepacked_out_cuda(X_pack, W_pack, Out);
}

torch::Tensor emulated_matmul_packed_out(
    torch::Tensor X,
    torch::Tensor W_pack,
    torch::Tensor X_pack,
    torch::Tensor Out,
    int64_t mode) {
    check_cuda_contiguous(X, "X");
    check_cuda_contiguous(W_pack, "W_pack");
    check_cuda_contiguous(X_pack, "X_pack");
    check_cuda_contiguous(Out, "Out");
    TORCH_CHECK(X.dtype() == torch::kFloat32, "X must be FP32");
    TORCH_CHECK(W_pack.dtype() == torch::kFloat16, "W_pack must be FP16");
    TORCH_CHECK(X_pack.dtype() == torch::kFloat16, "X_pack must be FP16");
    TORCH_CHECK(Out.dtype() == torch::kFloat32, "Out must be FP32");
    TORCH_CHECK(X.dim() == 2 && W_pack.dim() == 2 && X_pack.dim() == 2 && Out.dim() == 2,
                "all tensors must be matrices");
    TORCH_CHECK(X.device() == W_pack.device() && X.device() == X_pack.device() && X.device() == Out.device(),
                "all tensors must be on the same device");

    const int64_t segments = segments_for_mode(mode);
    const int64_t M = X.size(0);
    const int64_t K = X.size(1);
    const int64_t N = W_pack.size(1);
    TORCH_CHECK(K % 8 == 0 && N % 8 == 0, "K and N should be multiples of 8");
    TORCH_CHECK(W_pack.size(0) == segments * K,
                "W_pack must have shape [segments*K, N]");
    TORCH_CHECK(X_pack.size(0) == M && X_pack.size(1) == segments * K,
                "X_pack must have shape [M, segments*K]");
    TORCH_CHECK(Out.size(0) == M && Out.size(1) == N,
                "Out must have shape [M, N]");

    return emulated_matmul_packed_out_cuda(X, W_pack, X_pack, Out, mode);
}

torch::Tensor pack_scaled_weight(torch::Tensor W, int64_t scale) {
    check_cuda_contiguous(W, "W");
    TORCH_CHECK(W.dtype() == torch::kFloat32, "W must be FP32");
    TORCH_CHECK(W.dim() == 2, "W must have shape [K, N]");
    TORCH_CHECK(W.size(0) > 0 && W.size(1) > 0, "W dimensions must be positive");
    TORCH_CHECK(W.size(0) % 8 == 0 && W.size(1) % 8 == 0,
                "K and N should be multiples of 8");
    check_scale(scale);
    return pack_scaled_weight_cuda(W, scale);
}

torch::Tensor pack_scaled_activation_out(
    torch::Tensor X, torch::Tensor X_pair, int64_t scale) {
    check_cuda_contiguous(X, "X");
    check_cuda_contiguous(X_pair, "X_pair");
    TORCH_CHECK(X.dtype() == torch::kFloat32, "X must be FP32");
    TORCH_CHECK(X_pair.dtype() == torch::kFloat16, "X_pair must be FP16");
    TORCH_CHECK(X.dim() == 2 && X_pair.dim() == 3,
                "X must be [M,K] and X_pair must be [2,M,K]");
    TORCH_CHECK(X.device() == X_pair.device(),
                "X and X_pair must be on the same device");
    TORCH_CHECK(X_pair.size(0) == 2 && X_pair.size(1) == X.size(0) && X_pair.size(2) == X.size(1),
                "X_pair must have shape [2,M,K]");
    check_scale(scale);
    return pack_scaled_activation_out_cuda(X, X_pair, scale);
}

torch::Tensor scaled_two_gemm_out(
    torch::Tensor X,
    torch::Tensor W_pair,
    torch::Tensor X_pair,
    torch::Tensor Out,
    int64_t scale) {
    check_cuda_contiguous(X, "X");
    check_cuda_contiguous(W_pair, "W_pair");
    check_cuda_contiguous(X_pair, "X_pair");
    check_cuda_contiguous(Out, "Out");
    TORCH_CHECK(X.dtype() == torch::kFloat32, "X must be FP32");
    TORCH_CHECK(W_pair.dtype() == torch::kFloat16, "W_pair must be FP16");
    TORCH_CHECK(X_pair.dtype() == torch::kFloat16, "X_pair must be FP16");
    TORCH_CHECK(Out.dtype() == torch::kFloat32, "Out must be FP32");
    TORCH_CHECK(X.dim() == 2 && W_pair.dim() == 3 && X_pair.dim() == 3 && Out.dim() == 2,
                "expected X[M,K], W_pair[2,K,N], X_pair[2,M,K], Out[M,N]");
    TORCH_CHECK(X.device() == W_pair.device() && X.device() == X_pair.device() && X.device() == Out.device(),
                "all tensors must be on the same device");

    const int64_t M = X.size(0);
    const int64_t K = X.size(1);
    TORCH_CHECK(W_pair.size(0) == 2 && W_pair.size(1) == K,
                "W_pair must have shape [2,K,N]");
    const int64_t N = W_pair.size(2);
    TORCH_CHECK(X_pair.size(0) == 2 && X_pair.size(1) == M && X_pair.size(2) == K,
                "X_pair must have shape [2,M,K]");
    TORCH_CHECK(Out.size(0) == M && Out.size(1) == N,
                "Out must have shape [M,N]");
    TORCH_CHECK(K % 8 == 0 && N % 8 == 0,
                "K and N should be multiples of 8");
    check_scale(scale);

    return scaled_two_gemm_out_cuda(X, W_pair, X_pair, Out, scale);
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("pack_weight", &pack_weight, py::arg("W"), py::arg("mode") = 3);
    m.def("pack_activation_out", &pack_activation_out,
          py::arg("X"), py::arg("X_pack"), py::arg("mode") = 3);
    m.def("gemm_prepacked_out", &gemm_prepacked_out,
          py::arg("X_pack"), py::arg("W_pack"), py::arg("Out"));
    m.def("emulated_matmul_packed_out", &emulated_matmul_packed_out,
          py::arg("X"), py::arg("W_pack"), py::arg("X_pack"), py::arg("Out"), py::arg("mode") = 3);

    m.def("pack_scaled_weight", &pack_scaled_weight,
          py::arg("W"), py::arg("scale"));
    m.def("pack_scaled_activation_out", &pack_scaled_activation_out,
          py::arg("X"), py::arg("X_pair"), py::arg("scale"));
    m.def("scaled_two_gemm_out", &scaled_two_gemm_out,
          py::arg("X"), py::arg("W_pair"), py::arg("X_pair"), py::arg("Out"), py::arg("scale"));
}
