# Emulated FP32 v2: scaled two-GEMM experiment

This package retains the working expanded-K 3-term/4-term implementation and
adds a two-GEMM compensated approximation.

For a power-of-two scale `s`:

```text
A = Xh @ Wh
G = (Xh + s*Xl) @ (Wh + s*Wl)
Y = ((s-1)/s) * A + (1/s) * G
```

Ignoring the FP16 rounding used to build the mixed operands:

```text
Y = XhWh + XhWl + XlWh + s*XlWl
```

The method uses only two Tensor-Core GEMMs. The scale sweep measures the
trade-off between preserving the residual in the mixed FP16 operands and
amplifying the low-low term.

## Colab

```bash
!unzip -o emulated_fp32_scaled2gemm.zip
%cd emulated_fp32_scaled2gemm
!bash run_colab.sh
```

The useful output is written to `packed_cublas_results.log`.
