from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

setup(
    name="emulated_packed_cuda",
    ext_modules=[
        CUDAExtension(
            name="emulated_packed_cuda",
            sources=[
                "emulated_packed_bind.cpp",
                "emulated_packed_kernel.cu",
            ],
            libraries=["cublas"],
            extra_compile_args={
                "cxx": ["-O3"],
                "nvcc": ["-O3", "-lineinfo", "-Xptxas=-v"],
            },
        )
    ],
    cmdclass={"build_ext": BuildExtension.with_options(use_ninja=False)},
)
