#include <torch/extension.h>

#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <c10/cuda/CUDAStream.h>

#include <cublas_v2.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>

#include <cstdint>
#include <climits>

namespace {

inline int segments_for_mode(int mode) {
    if (mode == 0) return 1;
    if (mode == 1 || mode == 2) return 2;
    if (mode == 3) return 3;
    return 4;
}

inline void check_cublas(cublasStatus_t status, const char* where) {
    TORCH_CHECK(status == CUBLAS_STATUS_SUCCESS,
                where, " failed with cuBLAS status ", static_cast<int>(status));
}

template <int MODE>
__global__ void pack_weight_kernel(
    const float* __restrict__ W,
    half* __restrict__ W_pack,
    int64_t count) {
    const int64_t idx = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (idx >= count) return;

    const float value = W[idx];
    const half hi = __float2half_rn(value);
    const half lo = __float2half_rn(value - __half2float(hi));

    if constexpr (MODE == 0) {
        W_pack[idx] = hi;
    } else if constexpr (MODE == 1) {
        W_pack[idx] = hi;
        W_pack[count + idx] = hi;
    } else if constexpr (MODE == 2) {
        W_pack[idx] = hi;
        W_pack[count + idx] = lo;
    } else if constexpr (MODE == 3) {
        W_pack[idx] = hi;
        W_pack[count + idx] = lo;
        W_pack[2 * count + idx] = hi;
    } else {
        W_pack[idx] = hi;
        W_pack[count + idx] = lo;
        W_pack[2 * count + idx] = hi;
        W_pack[3 * count + idx] = lo;
    }
}

template <int MODE>
__global__ void pack_activation_kernel(
    const float* __restrict__ X,
    half* __restrict__ X_pack,
    int64_t M,
    int64_t K) {
    const int64_t idx = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    const int64_t count = M * K;
    if (idx >= count) return;

    const int64_t row = idx / K;
    const int64_t col = idx - row * K;
    constexpr int SEGMENTS = MODE == 0 ? 1 : ((MODE == 1 || MODE == 2) ? 2 : MODE);
    const int64_t row_base = row * (static_cast<int64_t>(SEGMENTS) * K) + col;

    const float value = X[idx];
    const half hi = __float2half_rn(value);
    const half lo = __float2half_rn(value - __half2float(hi));

    if constexpr (MODE == 0) {
        X_pack[row_base] = hi;
    } else if constexpr (MODE == 1) {
        X_pack[row_base] = hi;
        X_pack[row_base + K] = lo;
    } else if constexpr (MODE == 2) {
        X_pack[row_base] = hi;
        X_pack[row_base + K] = hi;
    } else if constexpr (MODE == 3) {
        X_pack[row_base] = hi;
        X_pack[row_base + K] = hi;
        X_pack[row_base + 2 * K] = lo;
    } else {
        X_pack[row_base] = hi;
        X_pack[row_base + K] = hi;
        X_pack[row_base + 2 * K] = lo;
        X_pack[row_base + 3 * K] = lo;
    }
}

__global__ void pack_scaled_pair_kernel(
    const float* __restrict__ src,
    half* __restrict__ pair,
    int64_t count,
    float scale) {
    const int64_t idx = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (idx >= count) return;

    const float value = src[idx];
    const half hi_h = __float2half_rn(value);
    const float hi = __half2float(hi_h);
    const half lo_h = __float2half_rn(value - hi);
    const float lo = __half2float(lo_h);

    // Plane 0 is the ordinary high half. Plane 1 encodes a scaled residual
    // into a second FP16 number so that it survives FP16 rounding.
    pair[idx] = hi_h;
    pair[count + idx] = __float2half_rn(hi + scale * lo);
}

void launch_pack_weight(
    const float* W,
    half* W_pack,
    int64_t count,
    int mode,
    cudaStream_t stream) {
    constexpr int THREADS = 256;
    const int blocks = static_cast<int>((count + THREADS - 1) / THREADS);
    switch (mode) {
        case 0: pack_weight_kernel<0><<<blocks, THREADS, 0, stream>>>(W, W_pack, count); break;
        case 1: pack_weight_kernel<1><<<blocks, THREADS, 0, stream>>>(W, W_pack, count); break;
        case 2: pack_weight_kernel<2><<<blocks, THREADS, 0, stream>>>(W, W_pack, count); break;
        case 3: pack_weight_kernel<3><<<blocks, THREADS, 0, stream>>>(W, W_pack, count); break;
        case 4: pack_weight_kernel<4><<<blocks, THREADS, 0, stream>>>(W, W_pack, count); break;
        default: TORCH_CHECK(false, "invalid mode");
    }
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}

void launch_pack_activation(
    const float* X,
    half* X_pack,
    int64_t M,
    int64_t K,
    int mode,
    cudaStream_t stream) {
    constexpr int THREADS = 256;
    const int64_t count = M * K;
    const int blocks = static_cast<int>((count + THREADS - 1) / THREADS);
    switch (mode) {
        case 0: pack_activation_kernel<0><<<blocks, THREADS, 0, stream>>>(X, X_pack, M, K); break;
        case 1: pack_activation_kernel<1><<<blocks, THREADS, 0, stream>>>(X, X_pack, M, K); break;
        case 2: pack_activation_kernel<2><<<blocks, THREADS, 0, stream>>>(X, X_pack, M, K); break;
        case 3: pack_activation_kernel<3><<<blocks, THREADS, 0, stream>>>(X, X_pack, M, K); break;
        case 4: pack_activation_kernel<4><<<blocks, THREADS, 0, stream>>>(X, X_pack, M, K); break;
        default: TORCH_CHECK(false, "invalid mode");
    }
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}

void launch_pack_scaled_pair(
    const float* src,
    half* pair,
    int64_t count,
    int64_t scale,
    cudaStream_t stream) {
    constexpr int THREADS = 256;
    const int blocks = static_cast<int>((count + THREADS - 1) / THREADS);
    pack_scaled_pair_kernel<<<blocks, THREADS, 0, stream>>>(
        src, pair, count, static_cast<float>(scale));
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}

void gemm_row_major_fp16_fp32(
    const half* X,
    const half* W,
    float* Out,
    int M,
    int N,
    int K,
    float alpha,
    float beta) {
    cublasHandle_t handle = at::cuda::getCurrentCUDABlasHandle();
    auto torch_stream = c10::cuda::getCurrentCUDAStream();
    cudaStream_t stream = torch_stream.stream();
    check_cublas(cublasSetStream(handle, stream), "cublasSetStream");

    // cuBLAS is column-major. Row-major C = XW is computed as
    // C^T = W^T X^T without moving data.
    check_cublas(
        cublasGemmEx(
            handle,
            CUBLAS_OP_N,
            CUBLAS_OP_N,
            N,
            M,
            K,
            &alpha,
            W,
            CUDA_R_16F,
            N,
            X,
            CUDA_R_16F,
            K,
            &beta,
            Out,
            CUDA_R_32F,
            N,
            CUBLAS_COMPUTE_32F,
            CUBLAS_GEMM_DEFAULT_TENSOR_OP),
        "cublasGemmEx");
}

}  // namespace

torch::Tensor pack_weight_cuda(torch::Tensor W, int64_t mode) {
    c10::cuda::CUDAGuard guard(W.device());
    const int64_t K = W.size(0);
    const int64_t N = W.size(1);
    const int segments = segments_for_mode(static_cast<int>(mode));
    auto W_pack = torch::empty(
        {segments * K, N},
        torch::TensorOptions().dtype(torch::kFloat16).device(W.device()));

    auto stream = c10::cuda::getCurrentCUDAStream().stream();
    launch_pack_weight(
        W.data_ptr<float>(),
        reinterpret_cast<half*>(W_pack.data_ptr<at::Half>()),
        K * N,
        static_cast<int>(mode),
        stream);
    return W_pack;
}

torch::Tensor pack_activation_out_cuda(torch::Tensor X, torch::Tensor X_pack, int64_t mode) {
    c10::cuda::CUDAGuard guard(X.device());
    auto stream = c10::cuda::getCurrentCUDAStream().stream();
    launch_pack_activation(
        X.data_ptr<float>(),
        reinterpret_cast<half*>(X_pack.data_ptr<at::Half>()),
        X.size(0),
        X.size(1),
        static_cast<int>(mode),
        stream);
    return X_pack;
}

torch::Tensor gemm_prepacked_out_cuda(torch::Tensor X_pack, torch::Tensor W_pack, torch::Tensor Out) {
    c10::cuda::CUDAGuard guard(X_pack.device());
    const int64_t M64 = X_pack.size(0);
    const int64_t K64 = X_pack.size(1);
    const int64_t N64 = W_pack.size(1);
    TORCH_CHECK(M64 <= INT_MAX && N64 <= INT_MAX && K64 <= INT_MAX,
                "matrix dimensions exceed cuBLAS int32 limits");

    gemm_row_major_fp16_fp32(
        reinterpret_cast<const half*>(X_pack.data_ptr<at::Half>()),
        reinterpret_cast<const half*>(W_pack.data_ptr<at::Half>()),
        Out.data_ptr<float>(),
        static_cast<int>(M64),
        static_cast<int>(N64),
        static_cast<int>(K64),
        1.0f,
        0.0f);
    return Out;
}

torch::Tensor emulated_matmul_packed_out_cuda(
    torch::Tensor X,
    torch::Tensor W_pack,
    torch::Tensor X_pack,
    torch::Tensor Out,
    int64_t mode) {
    c10::cuda::CUDAGuard guard(X.device());
    auto stream = c10::cuda::getCurrentCUDAStream().stream();

    launch_pack_activation(
        X.data_ptr<float>(),
        reinterpret_cast<half*>(X_pack.data_ptr<at::Half>()),
        X.size(0),
        X.size(1),
        static_cast<int>(mode),
        stream);

    const int64_t M64 = X_pack.size(0);
    const int64_t K64 = X_pack.size(1);
    const int64_t N64 = W_pack.size(1);
    TORCH_CHECK(M64 <= INT_MAX && N64 <= INT_MAX && K64 <= INT_MAX,
                "matrix dimensions exceed cuBLAS int32 limits");

    gemm_row_major_fp16_fp32(
        reinterpret_cast<const half*>(X_pack.data_ptr<at::Half>()),
        reinterpret_cast<const half*>(W_pack.data_ptr<at::Half>()),
        Out.data_ptr<float>(),
        static_cast<int>(M64),
        static_cast<int>(N64),
        static_cast<int>(K64),
        1.0f,
        0.0f);
    return Out;
}

torch::Tensor pack_scaled_weight_cuda(torch::Tensor W, int64_t scale) {
    c10::cuda::CUDAGuard guard(W.device());
    const int64_t K = W.size(0);
    const int64_t N = W.size(1);
    auto W_pair = torch::empty(
        {2, K, N},
        torch::TensorOptions().dtype(torch::kFloat16).device(W.device()));

    auto stream = c10::cuda::getCurrentCUDAStream().stream();
    launch_pack_scaled_pair(
        W.data_ptr<float>(),
        reinterpret_cast<half*>(W_pair.data_ptr<at::Half>()),
        K * N,
        scale,
        stream);
    return W_pair;
}

torch::Tensor pack_scaled_activation_out_cuda(
    torch::Tensor X, torch::Tensor X_pair, int64_t scale) {
    c10::cuda::CUDAGuard guard(X.device());
    auto stream = c10::cuda::getCurrentCUDAStream().stream();
    launch_pack_scaled_pair(
        X.data_ptr<float>(),
        reinterpret_cast<half*>(X_pair.data_ptr<at::Half>()),
        X.numel(),
        scale,
        stream);
    return X_pair;
}

torch::Tensor scaled_two_gemm_out_cuda(
    torch::Tensor X,
    torch::Tensor W_pair,
    torch::Tensor X_pair,
    torch::Tensor Out,
    int64_t scale) {
    c10::cuda::CUDAGuard guard(X.device());
    auto stream = c10::cuda::getCurrentCUDAStream().stream();

    launch_pack_scaled_pair(
        X.data_ptr<float>(),
        reinterpret_cast<half*>(X_pair.data_ptr<at::Half>()),
        X.numel(),
        scale,
        stream);

    const int64_t M64 = X.size(0);
    const int64_t K64 = X.size(1);
    const int64_t N64 = W_pair.size(2);
    TORCH_CHECK(M64 <= INT_MAX && N64 <= INT_MAX && K64 <= INT_MAX,
                "matrix dimensions exceed cuBLAS int32 limits");

    const int M = static_cast<int>(M64);
    const int N = static_cast<int>(N64);
    const int K = static_cast<int>(K64);
    const int64_t x_plane = M64 * K64;
    const int64_t w_plane = K64 * N64;

    const half* X_base = reinterpret_cast<const half*>(X_pair.data_ptr<at::Half>());
    const half* W_base = reinterpret_cast<const half*>(W_pair.data_ptr<at::Half>());
    const half* X_hi = X_base;
    const half* X_mix = X_base + x_plane;
    const half* W_hi = W_base;
    const half* W_mix = W_base + w_plane;

    const float inv_scale = 1.0f / static_cast<float>(scale);
    const float alpha_hi = 1.0f - inv_scale;

    // Out = ((s - 1) / s) * (Xh Wh)
    gemm_row_major_fp16_fp32(
        X_hi, W_hi, Out.data_ptr<float>(), M, N, K, alpha_hi, 0.0f);

    // Out += (1 / s) * ((Xh + sXl)(Wh + sWl))
    gemm_row_major_fp16_fp32(
        X_mix, W_mix, Out.data_ptr<float>(), M, N, K, inv_scale, 1.0f);

    return Out;
}
