#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

# CUDAExtension needs a complete CUDA toolkit (especially nvcc), not only the
# CUDA runtime bundled with the PyTorch wheel.
if [[ -z "${CUDA_HOME:-}" || ! -x "${CUDA_HOME}/bin/nvcc" ]]; then
    if command -v nvcc >/dev/null 2>&1; then
        NVCC_PATH="$(readlink -f "$(command -v nvcc)")"
        export CUDA_HOME="$(dirname "$(dirname "$NVCC_PATH")")"
    elif [[ -x /usr/local/cuda/bin/nvcc ]]; then
        export CUDA_HOME=/usr/local/cuda
    else
        echo "ERROR: nvcc was not found." >&2
        echo "Enable a GPU runtime in Colab: Runtime -> Change runtime type -> T4 GPU," >&2
        echo "then reconnect/restart the runtime and run this script again." >&2
        echo >&2
        python - <<'PY' || true
import torch
print("torch version       :", torch.__version__)
print("torch.version.cuda  :", torch.version.cuda)
print("torch.cuda.available:", torch.cuda.is_available())
PY
        exit 1
    fi
fi

export PATH="${CUDA_HOME}/bin:${PATH}"
export LD_LIBRARY_PATH="${CUDA_HOME}/lib64:${LD_LIBRARY_PATH:-}"
export TORCH_CUDA_ARCH_LIST="7.5+PTX"

# Fail early with useful diagnostics instead of failing inside setup.py.
echo "CUDA_HOME : ${CUDA_HOME}"
echo "nvcc      : $(command -v nvcc)"
nvcc --version | tail -n 1
nvidia-smi --query-gpu=name,compute_cap --format=csv,noheader
python - <<'PY'
import torch
assert torch.cuda.is_available(), (
    "PyTorch cannot see a CUDA GPU. In Colab choose "
    "Runtime -> Change runtime type -> T4 GPU, then restart the runtime."
)
print("PyTorch   :", torch.__version__)
print("Torch CUDA:", torch.version.cuda)
print("GPU       :", torch.cuda.get_device_name(0))
PY

rm -rf build dist *.so *.egg-info __pycache__
python setup.py build_ext --inplace
python test_packed_cublas.py | tee packed_cublas_results.log
