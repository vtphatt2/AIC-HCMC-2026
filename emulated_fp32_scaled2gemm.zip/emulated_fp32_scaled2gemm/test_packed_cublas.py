from dataclasses import dataclass

import torch
import emulated_packed_cuda as ext

DEVICE = "cuda"
MODE_NAMES = {
    0: "1-term  XhWh",
    1: "2-term  XhWh + XlWh",
    2: "2-term  XhWh + XhWl",
    3: "3-term  expanded-K",
    4: "4-term  expanded-K",
}
SCALES = [2, 4, 8, 16, 32, 64, 128]


def segments_for_mode(mode: int) -> int:
    return {0: 1, 1: 2, 2: 2, 3: 3, 4: 4}[mode]


@dataclass
class PackedRunner:
    W_pack: torch.Tensor
    X_pack: torch.Tensor
    out: torch.Tensor
    mode: int

    @classmethod
    def create(cls, W: torch.Tensor, M: int, mode: int):
        K, N = W.shape
        segments = segments_for_mode(mode)
        W_pack = ext.pack_weight(W.contiguous(), mode)
        X_pack = torch.empty((M, segments * K), device=W.device, dtype=torch.float16)
        out = torch.empty((M, N), device=W.device, dtype=torch.float32)
        return cls(W_pack=W_pack, X_pack=X_pack, out=out, mode=mode)

    def __call__(self, X: torch.Tensor) -> torch.Tensor:
        return ext.emulated_matmul_packed_out(
            X, self.W_pack, self.X_pack, self.out, self.mode
        )

    def pack_only(self, X: torch.Tensor) -> torch.Tensor:
        return ext.pack_activation_out(X, self.X_pack, self.mode)

    def gemm_only(self) -> torch.Tensor:
        return ext.gemm_prepacked_out(self.X_pack, self.W_pack, self.out)


@dataclass
class ScaledTwoGemmRunner:
    W_pair: torch.Tensor
    X_pair: torch.Tensor
    out: torch.Tensor
    scale: int

    @classmethod
    def create(cls, W: torch.Tensor, M: int, scale: int):
        K, N = W.shape
        W_pair = ext.pack_scaled_weight(W.contiguous(), scale)
        X_pair = torch.empty((2, M, K), device=W.device, dtype=torch.float16)
        out = torch.empty((M, N), device=W.device, dtype=torch.float32)
        return cls(W_pair=W_pair, X_pair=X_pair, out=out, scale=scale)

    def __call__(self, X: torch.Tensor) -> torch.Tensor:
        return ext.scaled_two_gemm_out(
            X, self.W_pair, self.X_pair, self.out, self.scale
        )

    def pack_only(self, X: torch.Tensor) -> torch.Tensor:
        return ext.pack_scaled_activation_out(X, self.X_pair, self.scale)


def bench_cuda(fn, warmup=10, iters=50) -> float:
    for _ in range(warmup):
        fn()
    torch.cuda.synchronize()

    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    start.record()
    for _ in range(iters):
        fn()
    end.record()
    end.synchronize()
    return start.elapsed_time(end) / iters


def error_metrics(out: torch.Tensor, ref: torch.Tensor) -> dict:
    diff = (out - ref).float()
    abs_diff = diff.abs()
    ref_f = ref.float()
    return {
        "max_abs": abs_diff.max().item(),
        "mean_abs": abs_diff.mean().item(),
        "rel_l2": (torch.linalg.vector_norm(diff) / torch.linalg.vector_norm(ref_f)).item(),
        "rmse": torch.sqrt(torch.mean(diff * diff)).item(),
    }


def print_metrics(prefix: str, metrics: dict):
    print(
        f"{prefix:<34} "
        f"max_abs={metrics['max_abs']:.6e}  "
        f"mean_abs={metrics['mean_abs']:.6e}  "
        f"rel_l2={metrics['rel_l2']:.6e}  "
        f"rmse={metrics['rmse']:.6e}"
    )


def correctness_gate():
    print("=== micro correctness gate ===")
    torch.manual_seed(0)
    M = K = N = 16
    X = torch.randn(M, K, device=DEVICE, dtype=torch.float32)
    W = torch.randn(K, N, device=DEVICE, dtype=torch.float32)
    ref = torch.mm(X, W)

    for mode in (3, 4):
        runner = PackedRunner.create(W, M, mode)
        out = runner(X).clone()
        torch.cuda.synchronize()
        print_metrics(MODE_NAMES[mode], error_metrics(out, ref))

    print("\n--- scaled two-GEMM sweep ---")
    for scale in SCALES:
        runner = ScaledTwoGemmRunner.create(W, M, scale)
        out = runner(X).clone()
        torch.cuda.synchronize()
        print_metrics(f"2-GEMM scaled s={scale}", error_metrics(out, ref))


def full_benchmark(M=8192, K=1536, N=1536):
    print(f"\n=== full benchmark M={M}, K={K}, N={N} ===")
    torch.manual_seed(123)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.set_float32_matmul_precision("highest")

    X = torch.randn(M, K, device=DEVICE, dtype=torch.float32)
    W = torch.randn(K, N, device=DEVICE, dtype=torch.float32)

    ref = torch.empty((M, N), device=DEVICE, dtype=torch.float32)
    fp16_out = torch.empty((M, N), device=DEVICE, dtype=torch.float16)
    X16 = X.half().contiguous()
    W16 = W.half().contiguous()

    torch.mm(X, W, out=ref)
    torch.cuda.synchronize()

    fp32_ms = bench_cuda(lambda: torch.mm(X, W, out=ref))
    fp16_ms = bench_cuda(lambda: torch.mm(X16, W16, out=fp16_out))

    print(f"cuBLAS FP32, preallocated out: {fp32_ms:.3f} ms")
    print(f"cuBLAS FP16, preallocated out: {fp16_ms:.3f} ms")

    results = []

    print("\n--- expanded-K references ---")
    for mode in (3, 4):
        runner = PackedRunner.create(W, M, mode)
        runner.pack_only(X)
        torch.cuda.synchronize()
        pack_ms = bench_cuda(lambda: runner.pack_only(X))
        gemm_ms = bench_cuda(runner.gemm_only)
        total_ms = bench_cuda(lambda: runner(X))
        out = runner(X).clone()
        torch.cuda.synchronize()
        metrics = error_metrics(out, ref)
        results.append((MODE_NAMES[mode], total_ms, metrics))
        print(
            f"{MODE_NAMES[mode]:<34} "
            f"pack={pack_ms:7.3f} ms  gemm={gemm_ms:7.3f} ms  "
            f"total={total_ms:7.3f} ms  speedup={fp32_ms / total_ms:5.2f}x"
        )
        print_metrics("  accuracy", metrics)

    print("\n--- scaled two-GEMM sweep ---")
    for scale in SCALES:
        runner = ScaledTwoGemmRunner.create(W, M, scale)
        runner.pack_only(X)
        torch.cuda.synchronize()
        pack_ms = bench_cuda(lambda: runner.pack_only(X))
        total_ms = bench_cuda(lambda: runner(X))
        gemm_est_ms = max(total_ms - pack_ms, 0.0)
        out = runner(X).clone()
        torch.cuda.synchronize()
        metrics = error_metrics(out, ref)
        name = f"2-GEMM scaled s={scale}"
        results.append((name, total_ms, metrics))
        print(
            f"{name:<34} "
            f"pack={pack_ms:7.3f} ms  gemm~= {gemm_est_ms:7.3f} ms  "
            f"total={total_ms:7.3f} ms  speedup={fp32_ms / total_ms:5.2f}x"
        )
        print_metrics("  accuracy", metrics)

    print("\n=== selection rules ===")
    for threshold in (1e-4, 2e-5, 1e-5):
        candidates = [r for r in results if r[2]["rel_l2"] <= threshold]
        if candidates:
            best = min(candidates, key=lambda r: r[1])
            print(
                f"rel_l2 <= {threshold:.0e}: {best[0]}, "
                f"{best[1]:.3f} ms, {fp32_ms / best[1]:.2f}x vs FP32"
            )
        else:
            print(f"rel_l2 <= {threshold:.0e}: no candidate")


if __name__ == "__main__":
    assert torch.cuda.is_available(), "CUDA GPU is required"
    props = torch.cuda.get_device_properties(0)
    print(f"GPU: {props.name}, compute capability {props.major}.{props.minor}")
    correctness_gate()
    full_benchmark()
